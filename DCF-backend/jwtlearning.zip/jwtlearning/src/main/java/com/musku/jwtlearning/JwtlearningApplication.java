package com.musku.jwtlearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtlearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtlearningApplication.class, args);
	}

}
