package com.musku.jwtlearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtlearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
